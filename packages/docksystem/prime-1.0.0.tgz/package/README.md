import { defineConfig } from 'tsup'

```
export default defineConfig({
  entry: ['src/index.ts'],
  format: ['cjs', 'esm'],
  dts: true,
  clean: true,
  // This forcefully injects React into the scope of every bundled file
  banner: {
    js: "import React from 'react';",
  },
  // Keep this as a backup
  esbuildOptions(options) {
    options.jsx = 'automatic'
  }
})
```

rm -rf dist .turbo node_modules/.cache

ls node_modules/@primetimetran/docksystem/dist

"main": "./dist/index.cjs", // For old CJS fallbacks
"module": "./dist/index.js", // For old ESM fallbacks (pointing to .js since type: module)

$ npm run build && npm pack && mv primetimetran-docksystem-1.0.0.tgz prime-1.0.0.tgz
